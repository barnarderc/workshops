


oneway.test.means <- function(DV, IV){
    
    require(stats, quietly = T)
    
    means <- tapply(DV[!is.na(DV) & !is.na(IV)], IV[!is.na(DV) & !is.na(IV)], mean)

    oneway_anova <- oneway.test(DV ~ IV)
    
    data <- paste0("data:  ", deparse(substitute(DV)), " and ", deparse(substitute(IV)))
    
    cat(noquote(data), "\n", "\n", "Group Means", "\n", "\n")
    print(means)
    return(oneway_anova)
    
    
}




