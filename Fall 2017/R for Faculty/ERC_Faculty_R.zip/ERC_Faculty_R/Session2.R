#---------------------------------------------------
# Intro to R - Session 2
# Prepared by Patricia Kirkland and Carolyn Silverman
# Last updated: 7 December 2017
#---------------------------------------------------

## clear the workspace
rm(list=ls(all=TRUE))

## load packages
library(foreign)
library(dplyr)
library(car)
library(ggplot2)

## set working directory
setwd("~/Desktop/ERC_Faculty_R")

## load dataset
load("muni_25K_finance_data.RData")

## some basic info about data
dim(COG.muni.25K)
names(COG.muni.25K)

## one way to change the name of a data frame
COG <- COG.muni.25K 
## remove the original copy (optional)
COG.muni.25K <- NULL

#---------------------------------------------------
#  DATA MANIPULATION
#---------------------------------------------------

#### subset- take certain variables or rows only

## keep only specified columns
COG.subset <- COG[, c(1:4, 6:8, 9, 10, 25:554)]

## drop variables using select() from the dplyr package
## note the - before the variable names; leave out the - to select variables to keep
COG.subset <- dplyr::select(COG.subset, -SortCode, -SurveyYr, -County, -Type.Code)

## subset based on one or more condition(s)

## use the subset() function
COG.50K <- subset(COG.subset, Population >= 50000)
## or use the filter() function from the dplyr package
COG.25K <- filter(COG.subset, Population < 25000) 

COG.50K.NE <- filter(COG.subset, Population >= 50000 & Census.Region == 1)

## Exercise
## filter COG.subset so it contains observations in Census.Region 2 or 4 with Population less than 25000 
## assign to the resulting subset to a data frame called COG.25K.WMW


## subset based on median population
COG.large <- filter(COG.subset, Population > median(Population))
COG.small <- filter(COG.subset, Population < median(Population))

## nest dplyr functions to select rows & columns at the same time
cities.100K <- dplyr::select(filter(COG, Population <= 100000), 
                             Year4, ID, State.Code, Name, Census.Region, Population)

## append rows of data
COG.subset2 <- rbind(COG.50K, COG.25K)


#---------------------------------------------------
#  MERGING DATA
#---------------------------------------------------

## read in a new dataset
fips <- read.dta("GOVS to FIPS Crosswalk.dta")
## you can select variables to keep or drop (optional)
fips <- select(fips, -areaname)

## need to rename some variables to merge on
## one option is rename() in the dplyr package
COG.subset <- rename(COG.subset, govsid = ID, govsstate = State.Code)
fips <- rename(fips, Name = name)


## the dplyr package has several merge options--- left_join() is probably most commonly used
#### left_join(x, y) merges 2 data frames x & y, returning all rows from x and all columns from x & y
#### dplyr supports the following merge functions:  
#### inner_join(), left_join(), right(join), semi_join(), anti_join(), and full_join()

COG.fips <- left_join(COG.subset, fips)

## note the warning message 
## also, we're left with 427 observations in COG.subset without matches in fips
length(COG.fips$fipsplace[is.na(COG.fips$fipsplace)])

class(fips$Name)
class(COG.subset$Name)

COG.subset$Name <- as.character(COG.subset$Name)

length(COG.fips$fipsplace[is.na(COG.fips$fipsplace)])

## you can (but do not have) to specify variables to use for merge
COG.fips <- left_join(COG.subset, fips, by=c("govsid", "govsstate", "Name"))


#---------------------------------------------------
#  CODING/RECODING VARIABLES
#---------------------------------------------------

# use recode function in the car package
# census regions --- 1 = Northeast / 2 = Midwest / 3 = South / 4 = West

COG.fips <- within(COG.fips, {
   
    ## create and code a variable for population categories
    Population.Category <- NULL
    Population.Category[Population < summary(COG.fips$Population)[2]] <- "Small"
    Population.Category[Population > summary(COG.fips$Population)[2] & Population < summary(COG.fips$Population)[5]] <- "Medium"
    Population.Category[Population > summary(COG.fips$Population)[5]] <- "Large"

    ## recode to replace region number with region name
    Census.Region <- recode(Census.Region, recodes = "1='Northeast'; 2='Midwest'; 3='South'; 4='West'")
})

## perform math operations with one or more variable(s)
COG.fips <- within(COG.fips, {
    Total.Revenue.PC <- Total.Revenue/Population
    Total.Taxes.PC <- Total.Taxes/Population

    log.Total.Revenue.PC <- log(Total.Revenue.PC)
    log.Total.Taxes.PC <- log(Total.Taxes.PC)
})

## Exercise
## within COG.fips, create variables Total.Expenditure.PC (total expenditure per capita) 
## and log.Total.Expenditure.PC (log total expenditure per capita)


#save the data frame as a .RData file
save(COG.fips, file = "muni_finance_data_cleaned.RData")

#clear the workspace and reload the data
rm(list=ls(all=TRUE))
load("muni_finance_data_cleaned.RData")


#---------------------------------------------------
#  GGPLOT FOR DATA VISUALIZATION
#---------------------------------------------------

## create factors-- factors designate groups or categories (this is optional, depending on the figures you need)
class(COG.fips$Population.Category)
COG.fips$Population.Category <- factor(COG.fips$Population.Category, 
                                       levels = c("Small", "Medium", "Large"))

COG.fips$Census.Region <- factor(COG.fips$Census.Region, 
                                 levels = c("Northeast", "Midwest", "South", "West"))

#plot Total.Expenditure.PC vs. Total.Revenue.PC 
#include a linear line of best  through the data
plot <- ggplot(COG.fips, aes(x=Total.Revenue.PC, y=Total.Expenditure.PC)) + 
  geom_point(alpha=.5) + geom_smooth(method = "lm")
plot

## Exercise
## plot Total.Expenditure.PC vs. Total.Revenue.PC for medium-sized populations
## include a linear line of best  through the data
## (hint: use the filter() function)



#plot Total.Expenditure.PC vs. Total.Revenue.PC for each population size using facet.grid
plot_3 <- ggplot(COG.fips, aes(x=Total.Revenue.PC, y=Total.Expenditure.PC)) + 
  geom_point(alpha=.5) + 
  geom_smooth(method = "lm") +
  facet_grid(Population.Category ~ .) 
plot_3  

#plot total revenue (PC) vs property tax (PC)
plot_4 <- ggplot(COG.fips, aes(x=Property.Tax/Population, y=Total.Revenue.PC)) +
  geom_point(alpha=.5) + 
  geom_smooth(method="lm", formula=y~x) 
plot_4

#plot total revenue (PC) vs property tax (PC) for each census region and each population (size) category
plot_5 <- plot_4 + facet_grid(Census.Region ~ Population.Category) +
  geom_smooth(method="lm", formula=y~x, se=FALSE) +
  theme_bw() +
  xlab("Property Tax (per capita)") +
  ylab("Total Revenue (per capita)")
plot_5

#plot total revenue (PC) vs property tax (PC) for each census region and each population (size) category
#use the %+% operator to select new data to plot
plot_6 <- plot_5 %+% aes(x=log((Property.Tax/Population)+1), y=log(Total.Revenue.PC+1)) +
  xlab("Property Tax (per capita logged)") +
  ylab("Total Revenue (per capita logged)")
plot_6    

#plot property tax (PC) colored by region
plot_7 <- ggplot(COG.fips, aes(x=(Property.Tax/Population), fill=Census.Region)) + 
  geom_histogram(binwidth=.05, alpha=.8)
plot_7

## Exercise
## Use the %+% operator (updating plot_7) to plot the log property tax (PC) colored by region


## saving plots: ggsave
ggsave(file="revenue_plot.pdf", plot_6, height=6, width = 4)


#---------------------------------------------------
#  STARGAZER
#---------------------------------------------------

library(stargazer)

stargazer(select(COG.fips, Total.Expenditure.PC, Total.Revenue.PC, Total.Taxes.PC),
          type = "html", title = "Summary Statistics", 
          out = "summary_statistics_table.htm")


## some regression models

fit_1 <- lm(Total.Expenditure.PC ~ Total.Taxes.PC, data=COG.fips)
summary(fit_1)

fit_2 <- lm(Total.Expenditure.PC ~ Total.Taxes.PC + Census.Region, data=COG.fips)
summary(fit_2)

fit_3 <- lm(Total.Expenditure.PC ~ Total.Taxes.PC + Population + Census.Region, data=COG.fips)
summary(fit_3)

fit_4 <- lm(Total.Expenditure.PC ~ Total.Taxes.PC + Population + Census.Region + Population.Category, data=COG.fips)
summary(fit_4)

stargazer(fit_1, fit_2, fit_3, fit_4,
          omit = c("Census.Region", "Population.Category"),
          add.lines = list(c("Fixed Effects", "N/A", "Region", "Region", "Region, Size")),
          title = "Results",
          type = "html",
          out = "regression_table.htm")

#without the omit and add.lines arguments
stargazer(fit_1, fit_2, fit_3, fit_4,
          title = "Results",
          type = "html",
          out = "regression_table_2.htm")


#---------------------------------------------------
#  APPLY FUNCTIONS
#---------------------------------------------------

### tapply() -- takes a vector & returns a vector; performs function on subsets by grouping variable(s)

## check the frequency distribution (optional)
table(COG.fips$Census.Region)

## use tapply() to get group means (you can use other functions as well)
tapply(COG.fips$Total.Expenditure, COG.fips$Census.Region, mean, na.rm=TRUE)


### sapply() takes a list, a data frame, or a subset of a data frame, 
### performs a function on each element, and returns a vector

## basic example
sapply(COG.fips[, 7:15], mean, na.rm=TRUE)

## create a data frame of summary statistics

## start by obtaining the statistics using sapply()
COG_means <- sapply(COG.fips[, 7:15], mean, na.rm=TRUE)
COG_medians <- sapply(COG.fips[, 7:15], median, na.rm=TRUE)
COG_stdevs <- sapply(COG.fips[, 7:15], sd, na.rm=TRUE)

## create a vector of variable names
COG_variable <- names(COG.fips[, 7:15])

## bind the vectors by columns
COG_summary <- cbind.data.frame(COG_variable, COG_means, COG_medians, COG_stdevs)

## remove the row names
row.names(COG_summary) <- NULL

COG_summary

#### lapply() -- takes a list or data frame; returns a list

## EXAMPLE:  run the same regression on multiple DVs
## specify a list of variables
varlist <- c("Total.Expenditure.PC", "Total.Taxes.PC", "Total.Revenue.PC")

## run the same regression on multiple DVs
COG_models <- lapply(varlist, function(x) {
  
  lm(substitute(COG.fips$i ~ COG.fips$Population + COG.fips$Census.Region, list(i = x)))
  
})

## to perform the summary() function
COG_results <- lapply(COG_models, summary)

## The functions above can be combined into a single lapply() functions
COG_models_results <- lapply(varlist, function(x) {
  
  summary(lm(substitute(COG.fips$i ~ COG.fips$Population + COG.fips$Census.Region, list(i = x))))
  
})
COG_models_results

## extract the first element
COG_models_results[[1]]

## Add names to the elements in a list
names(COG_models_results) <- varlist
COG_models_results

##  you can extract them using the names you assigned
COG_models_results[["Total.Taxes.PC"]]

## extract more detailed information
COG_models_results[["Total.Taxes.PC"]]$coefficients
COG_models_results[["Total.Taxes.PC"]]$coefficients[, 1:2]
