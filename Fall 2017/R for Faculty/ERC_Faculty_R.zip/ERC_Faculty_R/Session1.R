#---------------------------------------------------
# Intro to R
# Prepared by Patricia Kirkland and Carolyn Silverman
# Last updated: 7 December 2017
#---------------------------------------------------

#---------------------------------------------------
# PERFORMING BASIC TASKS
#---------------------------------------------------

##### Setting up your work space
rm(list=ls(all=TRUE)) # clear all objects in memory
setwd("D:/temp/Faculty_R/Faculty_R")

##### Installing and loading packages
# 
# install.packages("dplyr", dependencies=TRUE)
# install.packages("ggplot2", dependencies=TRUE)
# install.packages("foreign", dependencies=TRUE)
# install.packages("xtable", dependencies = TRUE)
# install.packages("stargazer", dependencies = TRUE)
# install.packages("arm", dependencies = TRUE)
# install.packages("modeest", dependencies=T)
# install.packages("descr")
# install.packages("car")
# install.packages("pander")

# load packages
library(foreign)
library(xtable)
library(arm)
library(ggplot2)
library(dplyr)
library(stargazer)
library(modeest) 
library(descr)
library(pander)

# some useful packages:
# foreign --  load data formatted for other software
# xtable -- export code to produce tables in LaTeX
# arm -- applied regression and multi-level modeling
# ggplot2 -- make plots and figures
# dplyr -- user friendly data cleaning & manipulation
# more packages: http://cran.r-project.org/web/packages/


#---------------------------------------------------
#  PROGRAMMING BASICS
#---------------------------------------------------

## Basic calculations

4
"yes"
2+3
1039/49
46^700
(3.5+2.7)/(900*2)


## Assignment operator

x <- 3
x
y <- "this is a string"

###  Basic math operators & functions

# Arithmetic/Math/Numeric Operators
# 	+	addition
#	-	subtraction
#	*	multiplication
#	/	division
#	^ or **	exponentiation

z <- 1
y <- 0 # overwrites previous y value
x <- 5 
w <- 100

a <- z + y
a
b <- x^2
c <- x * w
d <- sqrt(w) + x
e <- log(w)
b; c; d; e

###  Logical Operators 

#	<	less than
#	<=	less than or equal to
#	>	greater than
#	>=	greater than or equal to
#	==	exactly equal to
#	!=	not equal to
#	!x	Not x
#	x | y	-- x OR y
#	x & y -- 	x AND y
#	isTRUE(x)	test if X is TRUE

x==5	# this is a logical operator

x <- TRUE	# assign logical values to variables
x
y <- FALSE
y==0

x | y

isTRUE(x)

## Exercise
## Use the isTRUE() function to check if x AND y are both true
## your code below
isTRUE(x & y)

## HELP
# funtion search
?table
# topic search
??variance

#---------------------------------------------------
# Data Structures in R
#---------------------------------------------------

## Vectors
# The function c() allows you to concatenate a bunch of items into a vector
x <- c(1,2,3,4)
x
x[2]

## Exercise
## create a vector with values ranging from 5 to 9 called y
## print the 5th element of y


z <- c(x,y)

# Another way to produce a vector containing a sequence of integers
q <- 1:5
a <- seq(from=2, to=100, by=2)

# You can repeat vectors multiple times

ab <- rep(1:5, times=10)
ab2 <- rep(1:5, 10) 
ab == ab2
all(ab == ab2)

cd <- rep(c(1,3,7,9), times=2)


## Data Frames
df <- data.frame(x = 1:5, y = 6:10)
df

# bind vectors as columns in a data frame
data <- data.frame(cbind(a, ab))

# bind vectors as rows in a data frame
data <- data.frame(rbind(a, ab))

# -----------------------------------------------
# Working with Data
# -----------------------------------------------

##### Read in data

# csv file
data <- read.csv("teachingratingsexcel.csv", header=TRUE)

# dtafile <- read.dta("fakedata.dta")

## look at variable names and dimensions
names(data)
dim(data)
nrow(data)
ncol(data)

# refer to specific rows or columns in a data frame
data[1,]    	# row 1 only
data[1:3,]	# rows 1 to 3 only
data[,1]		# column 1 only

# print all rows and columns 2 through 4 of the data
data[,c(2:4)]

# print rows 3 and 5 and column 5 of the data
data[c(3,5),]

head(data, 10)
data$course_eval
course_eval    	# error! why?

class(data)
class(data$course_eval)
class(data$female)

#####  Writing data to disk

write.csv(data, "evaluation_data.csv", row.names=FALSE)
save(data, file="evaluation_data.RData")  # save just a data frame
save.image(file="course_evaluations.RData")  # save your current workspace

rm(list=ls(all=TRUE))
load("evaluation_data.RData")

# -----------------------------------------------
# Basic Data Analysis
# -----------------------------------------------

# table() function
table(data$female, useNA="always")
mytable <- table(data$female, data$minority, useNA="always", dnn=c("Gender", "Race or Ethnicity"))
mytable

mytable <- mytable[c(2, 1, 3), c(2, 1, 3)]
mytable

row.names(mytable) <- c("Female", "Male", "NA")
colnames(mytable) <- c("Minority", "White", "NA")
mytable

margin.table(mytable, 1)
margin.table(mytable, 2)

prop.table(mytable)
prop.table(mytable, 1) #row percentages
prop.table(mytable, 2) #column percentages

# freq() function from the descr package-- also produces a barplot (add plot = FALSE to omit)
## load the descr package

freq(data$female)
freq(data$minority, plot = FALSE) 

# crosstab() function (in descr pkg)-- also produces a mosaic plot (add plot = FALSE to omit)
crosstab(data$minority, data$female)
crosstab(data$minority, data$female, prop.c = TRUE) 

## Exercise
## use the crosstab() function on the variables nnenglish and minority 
## include both row and column proportions 


##### Looking at data: basic histograms and scatterplots

# hist()
hist(data$course_eval, breaks=50, main="Histogram of Outcome Variable - Course Evaluation", xlab="Outcome Variable Y")

# plot()
plot(data$beauty, data$course_eval, main="Scatterplot of Beauty and Course Evaluations", pch=16)

# save to disk
pdf("basic_plot.pdf")
plot(data$age, data$course_eval, main="Scatterplot of Age and Course Evaluations", pch=2)
dev.off()


#### A few basic analyses & statistical tests 

# summary statistics
summary(data)
summary(data$course_eval)

quantile(data$course_eval)
min(data$course_eval)
max(data$course_eval)

## mean
mean(data$course_eval, na.rm=TRUE)
mean(data$course_eval[data$female == 0])
mean(data$course_eval[data$female == 1])

## Exercise
## Find the mean of the beauty variable for male and female instructors


## median
median(data$course_eval, na.rm=TRUE)

## mode
mfv(data$course_eval) # basic evaluation - most frequent value

## standard deviation
sd(data$course_eval, na.rm=TRUE)

## by() function returns descriptive statistics by group or category
by(data$course_eval, data$female, summary)
by(data$course_eval, data$female, mean, na.rm=TRUE)

## Exercise
## use the by() function to get the median course_eval grouped by minority


## correlation 
cor(data$course_eval, data$beauty, use="complete.obs") ## Pearson correlation is the default
cor(data$course_eval, data$beauty, use="complete.obs", method="spearman")

## Exercise
## calculate the correlation between course_eval and beauty for female professors
## repeat for male professors


## correlation with significance test 
cor.test(data$course_eval, data$beauty, use="complete.obs")

## Exercise
# Is there a statistically significant correlation between course_eval and beauty 
# for female professors? What about male professors?


## t-test
t.test(data$course_eval ~ data$female)  # independent 2-group - first variable is numeric, second is binary factor
t.test(data$course_eval[data$female == 0], data$course_eval[data$female == 1])  # independent 2-group - both numeric variables

## Exercise
## Compare means of course evaluations for minority and non-minority instructors.
## Is the difference in means statistically significant?


## chi-square test
chisq.test(table(data$female, data$minority))

#### Regression models

fit_1 <- lm(course_eval ~ female, data=data)
summary(fit_1)

## include only a subset of the data

fit_1_male <- lm(course_eval ~ beauty, data=data, subset=female==0)
summary(fit_1_male)

fit_1_female <- lm(course_eval ~ beauty, data=data, subset=female==1)
summary(fit_1_female)


## include an interaction 

fit_2 <- lm(course_eval ~ female*beauty, data=data)
summary(fit_2)

fit_age <- lm(beauty ~ age*female, data=data)
summary(fit_age)

## include additional independent variables

fit_3 <- lm(course_eval ~ female + beauty + age, data=data)
summary(fit_3)

## add fixed effects

fit_4 <-  lm(course_eval ~ factor(intro) + female + beauty + age, data=data)
summary(fit_4)


## Exercise
## Specify your own model(s) based on your hypotheses (or speculation?) about the 
## factors that predict course evaluations.


## heteroskedasticity-robust standard errors

## packages
library(sandwich) 
library(lmtest)

summary(fit_3)
coeftest(fit_3, vcov=vcovHC(fit_3, type="HC0")) ## HC0 is the default
coeftest(fit_3, vcov=vcovHC(fit_3, type="HC1")) ## HC1 includes a degree of freedom correction (like , robust in Stata)

## Exercise
## Generate robust standard errors for the model you specified above.

