#It's good coding hygeine to make sure your environment is clear whenever starting something new in R
rm(list=ls())

#make sure you have the libraries you need
library(readxl)
library(diplyr)
install.packages("descr")
library(descr)

#import data
UnicefWaterData <- read_excel("C:/Users/casey/Downloads/UnicefWaterData.xlsx")

#take a look at variable headers, pay special attention to what everything is called / spelling / uppercase letters
names(UnicefWaterData)


#look at overall stats regarding your data
summary(UnicefWaterData)

#subset data so you're only looking at 2015
ERCData<-UnicefWaterData[which(UnicefWaterData$Year=="2015"),]
ERCData


#let's look at distribution
freq(ERCData$FreeFrmContamination_POP)
freq(ERCData$Region)

#kernel density
d<-density(ERCData$FreeFrmContamination_POP, na.rm=TRUE)
plot(d)

#mean
mean(ERCData$FreeFrmContamination_POP)
mean(ERCData$FreeFrmContamination_POP, na.rm=TRUE)

#median
median(ERCData$FreeFrmContamination_POP)
median(ERCData$FreeFrmContamination_POP, na.rm=TRUE)

#mode
getmode<-function(v){uniqv<-unique(v)
uniqv[which.max(tabulate(match(v,uniqv)))]}
getmode(ERCData$Region)

#range
range(ERCData$FreeFrmContamination_POP, na.rm=TRUE)
max(ERCData$FreeFrmContamination_POP, na.rm=TRUE)-min(ERCData$FreeFrmContamination_POP, na.rm=TRUE)

#standard deviation
sd(ERCData$FreeFrmContamination_POP, na.rm=TRUE)

#crosstabs
mycrosstab<-xtabs(~ERCData$Location+ERCData$Region)
ftable(mycrosstab)

#get rid of na's so you don't have to keep doing it
ERCDataClean<-na.omit(ERCData)

#######################################     Data Visualization

#histogram
hist(ERCData$FreeFrmContamination_POP,breaks=10,main="Population with Clean Water",xlab="Percentage")

#boxplot
boxplot(ERCData$FreeFrmContamination_POP)

#scatterplot
plot(ERCDataClean$SurfaceWater_School,ERCDataClean$FreeFrmContamination_POP,main="Example Scatterplot")

#check correlation
cor(ERCDataClean$FreeFrmContamination_POP,ERCDataClean$SurfaceWater_School)

#create a dummy variable with region where Europe = 1 and Not Europe = 0
ERCDataClean$EuropeDummy<-ifelse(ERCDataClean$Region=="Europe",1,0)
ERCDataClean$EuropeDummy

#create your first model
model1<-lm(ERCDataClean$FreeFrmContamination_POP~ERCDataClean$EuropeDummy)
summary(model1)

#example 2
model2<- lm(ERCDataClean$FreeFrmContamination_POP~ERCDataClean$SurfaceWater_School)
summary(model2)

#example 3
model3<- lm(ERCDataClean$FreeFrmContamination_POP~ERCDataClean$Region+ERCDataClean$SurfaceWater_School)
summary(model3)

#example 2, not just 2015
model2a<- lm(ERCData$FreeFrmContamination_POP~ERCData$SurfaceWater_School)
summary(model2a)

#example 3, not just 2015
model3a<- lm(ERCData$FreeFrmContamination_POP~ERCData$Region+ERCData$SurfaceWater_School)
summary(model3a)






