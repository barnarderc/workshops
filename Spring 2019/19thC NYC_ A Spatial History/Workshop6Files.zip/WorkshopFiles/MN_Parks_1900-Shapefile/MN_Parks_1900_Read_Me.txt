This shapefile is of Manhattan parks as of 1900. It was created by Teddy Ort and Brian Englemann.

The shapefile is used to create nearly all the maps in the book: 						
Barr, J. M. (2016). Building the Skyline: The Birth and Growth of Manhattan's Skyscrapers. New York: Oxford University Press.						
If you use this data please cite the book.						
						
Caveat Emptor: All attempts were made to collect and process this data as accurately as possible, but there are no guarantees about this.						

